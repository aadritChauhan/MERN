import { useEffect, useState } from "react";

export default function Projects() {

    const [project, setProject] = useState([]);

    useEffect(() => {
        const getProjects = async() =>{
            let res = await fetch("/jsonData/project.json");
            let jsondata = await res.json();
            setProject(jsondata);
        };  
        getProjects();
    }, []);

    return(
    
             <><h1 class="textAlign">My Projects </h1><div id="projectFlex">


            <div id="project">

                {project.map((d) => (
                    <div key={d.id}>
                        <h2 class="textAlign" style="text-decoration:underline">{d.title}</h2>
                        <div class="projectContent"><p style="text-align:center"> {d.content}</p></div>
                    </div>

                ))}



                <div class="projectPic">
                    <img src="<?php echo $record['photo']; ?>" />
                </div>



                <div><a href="<?php echo $record['url'];  ?>" style="font-weight:bold">Link to Project</a> </div>

            </div>

        </div></>
                               
                     
             
    );
}
import { useEffect, useState } from "react";

export default function SocialMedias() {

    const [socialMedia, setSocialMedia] = useState([]);

    useEffect(() => {
        const getSocialMedia = async() =>{
            let res = await fetch("/jsonData/socialMedia.json");
            let jsondata = await res.json();
            setSocialMedia(jsondata);
        };  
        getSocialMedia();
    }, []);

    return(
        
                       
                               
                               

    <div class="topMargin" id="cc"> 
    <h1 class="textAlign">Contact Me</h1>  
    <div class="socialCenter">   
    <div class="socialFlex">

    {socialMedia.map((d) => (


  <div key={d.id}>
      <h2 style="text-decoration:underline"> {d.name}</h2>

      <p>Link: <a href="{d.url}">{d.name}</a> </p>

     
        
        <img src="admin/image.php?type=socialMedia&id=<?php echo $record['id']; ?>&width=100&height=100" />

      

   </div>

))}   
      
    </div>
      </div>
      </div>

                           
                            
    );
}
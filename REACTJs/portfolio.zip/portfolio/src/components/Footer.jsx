export default function Footer() {
    return(
        <footer id="footer">
            <div className="copyrightText">
                &copy;Copyright 2023, Muskan Aggarwal, HTTP-5211
            </div>
        </footer>
    )
}
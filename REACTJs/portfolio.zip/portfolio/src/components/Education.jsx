import { useEffect, useState } from "react";

export default function Educations() {

    const [education, setEducation] = useState([]);

    useEffect(() => {
        const getEducations = async() =>{
            let res = await fetch("/jsonData/education.json");
            let jsondata = await res.json();
            setEducation(jsondata);
        };  
        getEducations();
    }, []);

    return(
        
                    <div>
                           <h1 class="textAlign">My Education</h1>  
                           <div class="educationFlexOuter">
                            <div class="educationFlex">    
                        {education.map((d) => (
                               
                                <div key={d.id}>
                                    <h2 class="textAlign"> {d.name} </h2>
                        
                                    <p class="textAlign"> {d.school}  </p>
                               </div>
                        ))}   
                               
                             </div>
                           </div>
                    </div>     
             
    );
}
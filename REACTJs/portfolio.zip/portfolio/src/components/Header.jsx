export default function Header() {
    return(
        <header> 
           {/* Navbar */}
            <nav id="flexNav">
                <p style="font-size:larger">
                Aadrit Chauhan
                </p>
                <div id="flexMenu">    
                <div>
                    <a href="#projectFlex">Projects</a>
                </div>
                <div>
                    <a href="#skil">Skills</a>
                </div>
                <div>
                    <a href="#cc">Contact </a>
                </div>
                <div>
                    <a href="#am">About Me</a>
                </div>
                </div>
            </nav>
    </header>
    )
}
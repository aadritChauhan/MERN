import { useEffect, useState } from "react";

export default function AboutMe() {

    const [aboutMe, setAboutMe] = useState([]);

    useEffect(() => {
        const getAboutMe = async() =>{
            let res = await fetch("/jsonData/aboutMe.json");
            let jsondata = await res.json();
            setAboutMe(jsondata);
        };  
        getAboutMe();
    }, []);

    return(
        <div class="topMargin" id="am">

            
                <h1 class="textAlign">About Me</h1>  
                <div class="aboutFlex">
                
                    <div>
                        {aboutMe.map((d) => (
                            <div key={d.id}>
                                <h2 class="textAlign" style="text-decoration:underline">{d.title}</h2>
                
                                <p class="textAlign"> {d.description} </p>
                                <img src="admin/image.php?type=aboutMe&id=<?php echo $record['id']; ?>&width=100&height=100"/> 
                        </div>
                        ))}   
                    </div>     
                 </div>       
        </div>
    );
}
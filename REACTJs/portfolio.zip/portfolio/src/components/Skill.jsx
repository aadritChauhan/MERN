import { useEffect, useState } from "react";

export default function Skills() {

    const [skill, setSkill] = useState([]);

    useEffect(() => {
        const getSkills = async() =>{
            let res = await fetch("/jsonData/skills.json");
            let jsondata = await res.json();
            setSkill(jsondata);
        };  
        getSkills();
    }, []);

    return(
        
                       
                               
                               <div class="topMargin" id="skil">
                               <h1 class="textAlign">My Skills</h1>
                               <div class="skillBorder">
                        {skill.map((d) => (

                              <div class="skillSize" key={d.id}>
                       
                                 
                                   <h2 style="text-decoration:underline"> {d.name}</h2>
                       
                                     <p>{d.percent}</p>
                       
                                     <div style="background-color:grey;">
                                         <div style="background-color: blue; height: 20px; width:<?php    echo $record['percent']; ?>%;">
                                         </div>
                                     </div>
                       
                               
                             </div>
                        ))}   

                             </div>
                             </div>
                               
                            
    );
}